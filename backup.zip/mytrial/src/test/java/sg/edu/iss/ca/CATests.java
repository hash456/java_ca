package sg.edu.iss.ca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CATests {

	@Test
	void contextLoads() {
	}

}
