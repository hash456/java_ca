package sg.edu.iss.ca.model;

public enum Role {
	ADMIN,MECHANIC;
}
